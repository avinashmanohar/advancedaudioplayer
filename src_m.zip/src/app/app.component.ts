import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AudioService } from './shared/audio.service';
import { timer, interval, Subscription } from 'rxjs';
import { MatSlideToggleChange } from '@angular/material/slide-toggle';
import { HelperService } from './shared/helper.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {

  constructor(private audio: AudioService, private ref: ChangeDetectorRef, private helper: HelperService) { }
  title = 'advancedaudioplayer';
  audioworkletRunning = '-';
  songDuration: string;

  maxDurationInSec = 0;
  currentSeek = 0;

  sliderMouseDown = false;

  url = 'https://raw.githubusercontent.com/mdn/webaudio-examples/master/multi-track/drums.mp3';
  seekSubscription: Subscription;

  frontDelay = 10;
  centerDelay = 0;
  rearDelay = 50;
  subDelay = 0;

  ngOnInit() {
    this.audio.audioworkletRunning.subscribe(d => {
      if (d) {
        this.audioworkletRunning = 'Yes';
      } else {
        this.audioworkletRunning = 'No';
      }
      this.ref.detectChanges();
    });

    this.audio.songDuration
      .subscribe(secs => {
        // this.seekSubscription.closed = false;
        if (!this.seekSubscription || this.seekSubscription.closed) {
          this.startTimer();
        }
        console.log(this.seekSubscription);
        this.songDuration = this.helper.convertPlaybackTime(secs);
        this.maxDurationInSec = secs;


      });

  }

  playLocal() {
    // this.audio.playSound('../assets/audio/audio8.mp3');
    this.audio.playSound(this.url, 0);
  }

  disconnect() {
    this.audio.disconnect();
    if (this.seekSubscription) {
      // console.log('Never reached');
      this.seekSubscription.unsubscribe();
    }
    this.maxDurationInSec = 0;
    this.currentSeek = 0;
  }

  slideToggle(event: MatSlideToggleChange) {
    this.audio.useWorklet = event.checked;
    if (this.seekSubscription) {
      this.audio.disconnect();
      const position = this.currentSeek / this.maxDurationInSec;
      this.audio.playSound(this.url, position);
    }
  }

  startTimer() {
    const source = interval(125);
    this.seekSubscription = source.subscribe(ts => {
      console.log(ts);
      if (this.currentSeek > this.maxDurationInSec) {
        this.currentSeek = this.maxDurationInSec;
        this.disconnect();
      }
      if (!this.sliderMouseDown) {
        this.currentSeek += 0.125;
      }

      this.ref.detectChanges();
    });

  }

  resetSeek() {
    if (this.currentSeek < this.maxDurationInSec) {
      if (!this.seekSubscription) {
        this.startTimer();
      }
    }
    this.audio.disconnect();
    const position = this.currentSeek / this.maxDurationInSec;
    this.audio.playSound(this.url, position);
  }
}
